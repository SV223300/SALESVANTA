export function LogoMark({ className = 'h-9 w-9' }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden="true">
      <defs>
        <linearGradient id="sv-line" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#2563eb" />
          <stop offset="1" stopColor="#06b6d4" />
        </linearGradient>
      </defs>
      <rect width="64" height="64" rx="16" fill="#000000" />
      <rect x="1" y="1" width="62" height="62" rx="15" fill="none" stroke="#1e293b" strokeWidth="1" />
      <path
        d="M18 42 L28 26 L36 34 L46 18"
        fill="none"
        stroke="url(#sv-line)"
        strokeWidth="4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="46" cy="18" r="4" fill="#06b6d4" />
    </svg>
  );
}

export function Logo({ className = '' }: { className?: string }) {
  return (
    <a
      href="#top"
      className={`group inline-flex items-center gap-2.5 ${className}`}
      aria-label="Salesvanta home"
    >
      <LogoMark className="h-9 w-9 transition-transform duration-300 group-hover:scale-105" />
      <span className="font-display text-lg font-bold tracking-tight text-white">
        Salesvanta
      </span>
    </a>
  );
}
